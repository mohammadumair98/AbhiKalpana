package com.example.abhikalpana;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class VolunteerRecyclerViewFragment extends Fragment {

    static ArrayList<String> name, branch, class_no, url;
    static ArrayList<Integer> age;
    static ImageView[] image;
    static RecyclerView memberListView;

    public VolunteerRecyclerViewFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_member_recycler_view, container, false);
        memberListView = (RecyclerView) view.findViewById(R.id.memberrv);
        Log.v("TAG", "KidsRecyclerViewFragment entered");
        final DatabaseReference childrendb = FirebaseDatabase.getInstance().getReference("firetry-54b4e");
        childrendb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    DataSnapshot memberList = dataSnapshot.child("Volunteers");
                    for (DataSnapshot npsnapshot : memberList.getChildren()) {
                        String n = (String) npsnapshot.child("Name").getValue();
                        name.add(n);
                        String b = (String) npsnapshot.child("Branch").getValue();
                        branch.add(b);

                    }

                }

                MyAdapter memberAdapter = new MyAdapter(getContext(), image, url, name, branch );
                memberListView.setAdapter(memberAdapter);
                memberListView.setLayoutManager(new LinearLayoutManager(getContext()));
                Log.v("TAG", "KidsRecyclerViewFragment entered");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
