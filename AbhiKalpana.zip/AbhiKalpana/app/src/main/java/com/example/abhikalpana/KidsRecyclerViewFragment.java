package com.example.abhikalpana;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class KidsRecyclerViewFragment extends Fragment {

    ArrayList<String> name;
    ArrayList<String> class_no;
    ArrayList<String> url;
    ArrayList<Integer> age;
    ImageView[] image;
    View view;
    RecyclerView memberListView;
    Context context;
    SearchView searchView;
    Button updateattendancebtn;
    MyAdapter memberAdapter;

    public KidsRecyclerViewFragment(Context context) {
        this.context = context;
    }

    public KidsRecyclerViewFragment() {

    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v("TAG", "KidsRecyclerViewFragment entered");

        name = new ArrayList<String>();
        class_no = new ArrayList<String>();
        age = new ArrayList<Integer>();

        view = inflater.inflate(R.layout.fragment_member_recycler_view, container, false);
        searchView = (SearchView) view.findViewById(R.id.searchView);
        searchView.setVisibility(View.GONE);
        updateattendancebtn = (Button) view.findViewById(R.id.updateattendancebtn);
        updateattendancebtn.setVisibility(View.GONE);

        memberListView = (RecyclerView) view.findViewById(R.id.memberrv);
        memberAdapter = new MyAdapter(context, image, url, name, age, class_no);
        memberListView.setAdapter(memberAdapter);
        memberListView.setLayoutManager(new LinearLayoutManager(context));

        final DatabaseReference childrendb = FirebaseDatabase.getInstance().getReference("Kids");
        childrendb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                        String n = npsnapshot.child("Name").getValue(String.class);
                        name.add(n);
                        Log.v("TAG", n);
                        String c = npsnapshot.child("Class").getValue(String.class);
                        class_no.add(c);
                        Integer a = npsnapshot.child("Age").getValue(Integer.class);
                        //Log.v("TAG", a.toString());
                        age.add(a);
                        memberAdapter.notifyDataSetChanged();
                        Log.v("TAG", "Data Received ");
                    }

                } else
                    Log.v("TAG", "Firebase Else entered");

                Log.v("TAG", "KidsRecyclerViewFragment exited");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        return view;

    }

}