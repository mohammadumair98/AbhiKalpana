package com.example.abhikalpana;

import android.content.Context;
import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class FragmentAdapter extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;

    public FragmentAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        myContext = context;
        this.totalTabs = totalTabs;
        Log.v("TAG", "Entered FragmentAdapter");
    }

    // this is for fragment tabs
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                KidsRecyclerViewFragment  kids= new KidsRecyclerViewFragment();
                Log.v("TAG", "KidsRecyclerViewFragment switch case entered");
                return kids;

            case 1:
                Fragment VolunteerRecyclerViewFragment = new Fragment();
                Log.v("TAG", "VolunteerRecyclerViewFragment switch case entered");
                return VolunteerRecyclerViewFragment;
            default:
                return null;
        }

    }

    // this counts total number of tabs
    @Override
    public int getCount() {
        return totalTabs;
    }
}
