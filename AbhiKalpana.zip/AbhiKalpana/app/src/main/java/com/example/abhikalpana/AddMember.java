package com.example.abhikalpana;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddMember extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_member);
    }
}