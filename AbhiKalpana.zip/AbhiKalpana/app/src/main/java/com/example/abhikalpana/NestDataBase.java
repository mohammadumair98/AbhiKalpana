package com.example.abhikalpana;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;


import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.InflateException;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class NestDataBase extends AppCompatActivity {

    TabLayout tabLayout;
    int tabposition;
    TextView appbarnametv;
    ViewPager viewPager;
    public static Context ct;
    public FrameLayout nestframelayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nest_data_base);

        Log.v("TAG", "Entered NestDataBAse");
        appbarnametv = (TextView) findViewById(R.id.appbarnametv);
        tabLayout = (TabLayout) findViewById(R.id.tab);
        viewPager=(ViewPager)findViewById(R.id.viewPager);
        nestframelayout = (FrameLayout) findViewById(R.id.nestframelayout);
        TabLayout.Tab childrentab = tabLayout.newTab();
        childrentab.setText("Children");
        TabLayout.Tab volunteertab = tabLayout.newTab();
        volunteertab.setText("Volunteers");
        tabLayout.setTabGravity(TabLayout.GRAVITY_CENTER);
        tabLayout.addTab(childrentab, 0);
        tabLayout.addTab(volunteertab, 1);

        Log.v("TAG", "Set Tab Layout");

        final FragmentAdapter adapter = new FragmentAdapter(this, getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
                KidsRecyclerViewFragment  kids = new KidsRecyclerViewFragment(getApplicationContext());
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.nestframelayout, kids);
                Log.v("TAG", "OnTabSelected Triggered");

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });



    }
}