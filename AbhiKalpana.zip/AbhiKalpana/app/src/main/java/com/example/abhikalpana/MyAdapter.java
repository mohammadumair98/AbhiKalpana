package com.example.abhikalpana;

import android.content.Context;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    ArrayList<String> url, name, branch, class_no;
    ArrayList<Integer> age;
    Context ct;
    ImageView[] dp;
    boolean kid, volunteer = false;

    public MyAdapter(Context c, ImageView[] image,ArrayList<String> ur, ArrayList<String> nam, ArrayList<Integer> ag, ArrayList<String> class_n ) {
        name = nam;
        dp = image;
        this.age = ag;
        class_no = class_n;
        ct = c;
        url = ur;
        kid = true;
    }

    public MyAdapter(Context c, ImageView[] image, ArrayList<String> ur, ArrayList<String> nam, ArrayList<String> branc) {
        ct = c;
        name = nam;
        dp = image;
        branch = branc;
        url = ur;
        volunteer = true;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.v("TAG", "MyAdapter entered");
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_member_list_layout, parent, false);
        Log.v("TAG","Fragment Member List Layout Inflated");
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.nametv.setText(name.get(position));
        holder.agetv.setText(age.get(position));
        holder.branchtv.setText(branch.get(position));
        holder.classtv.setText(class_no.get(position));
        /*Glide.with(this.ct)
                .load(url.get(position))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.dpimage);    */
        Log.v("TAG", "MyAdapter Complete");

    }

    @Override
    public int getItemCount() {
        return name.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nametv;
        TextView agetv;
        TextView branchtv;
        TextView classtv;
        Button morebtn;
        ImageView dpimage;
        public MyViewHolder(@NonNull View v) {
            super(v);
            nametv = (TextView) v.findViewById(R.id.nametv);
            agetv = (TextView) v.findViewById(R.id.agetv);
            if(volunteer == true)
                agetv.setVisibility(View.GONE);
            branchtv = (TextView) v.findViewById(R.id.branchtv);
            if(kid == true)
                branchtv.setVisibility(View.GONE);
            classtv = (TextView) v.findViewById(R.id.classtv);
            if(volunteer == true)
                classtv.setVisibility(View.GONE);
            morebtn = (Button) v.findViewById(R.id.morebtn);
            dpimage = (ImageView) v.findViewById(R.id.dpimage);
            Log.v("TAG","Elements Defined");

        }
    }

}
